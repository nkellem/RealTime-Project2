'use strict';

//initializes our app
const init = () => {
  getCanvas();
  joinRoom();
};

window.onload = init;
